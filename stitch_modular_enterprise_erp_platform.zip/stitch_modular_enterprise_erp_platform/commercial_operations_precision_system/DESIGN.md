---
name: Commercial Operations Precision System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#25005a'
  on-tertiary-container: '#9863ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#eaddff'
  tertiary-fixed-dim: '#d2bbff'
  on-tertiary-fixed: '#25005a'
  on-tertiary-fixed-variant: '#5a00c6'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
  data-mono-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  data-mono-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-3xs: 0.125rem
  space-2xs: 0.25rem
  space-xs: 0.375rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

This design system delivers an operational interface for mission-critical enterprise commerce, supply chain tracking, and financial reconciliation. It targets operations managers, financial controllers, and procurement officers who process high volumes of dense data under strict temporal constraints.

The visual style unites the structural reliability of contemporary enterprise platforms (such as modern SAP Fiori and NetSuite) with the typographic rigor, atomic hierarchy, and tactile precision of Stripe’s operational tooling. The visual language favors high data density, low cognitive interference, and strict spatial predictability. Every interaction emphasizes correctness over decoration: tabular figures align down to the sub-pixel, statuses carry unambiguous semantic weights, and micro-interactions supply instantaneous feedback through deterministic color shifts and state containment.

## Colors

The palette establishes an immutable hierarchy between operational structure, user actions, and state indications:

- **Foundation & Structural Neutrals:**
  - Base canvas: `#F8FAFC` (Canvas Muted) and `#FFFFFF` (Surface Elevated).
  - Borders & Dividers: `#E2E8F0` (Subtle boundary), `#CBD5E1` (Interactive border & grid delimiter).
  - Slate Neutrals: `#0F172A` (Primary text & deep brand), `#1E293B` (Secondary headings & dark shell surfaces), `#475569` (Body text), `#64748B` (Secondary/caption text), `#94A3B8` (Placeholder text & disabled glyphs).

- **Action & Brand Primaries:**
  - `#0F172A`: Primary operational control background.
  - `#2563EB`: Interactive focus states, actionable hyperlinks, primary command triggers, active tab indicators. Hover state scales to `#1D4ED8`.

- **Semantic Multi-State Tokens:**
  - **Success / Settled / Authorized:** `#059669` (Text/Icon), `#10B981` (Solid indicator), `#ECFDF5` (Surface fill), `#A7F3D0` (Border).
  - **Warning / Draft / Pending Stock:** `#D97706` (Text/Icon), `#F59E0B` (Solid indicator), `#FFFBEB` (Surface fill), `#FDE68A` (Border).
  - **Critical / Blocked / Overdue:** `#DC2626` (Text/Icon), `#EF4444` (Solid indicator), `#FEF2F2` (Surface fill), `#FECACA` (Border).
  - **Processing / In-Transit / Expedition:** `#7C3AED` (Text/Icon), `#8B5CF6` (Solid indicator), `#F5F3FF` (Surface fill), `#DDD6FE` (Border).
  - **Informational / Analytical / Neutral Metric:** `#0284C7` (Text/Icon), `#0EA5E9` (Solid indicator), `#F0F9FF` (Surface fill), `#BAE6FD` (Border).

Dark mode maps these tokens symmetrically: canvas shifts to `#0B0F17`, surfaces step to `#1E293B`, subtle borders invert to `#334155`, and semantic indicator surfaces use 12% alpha fills with high-luminance foreground text.

## Typography

The type system runs on a singular, unified installation of Inter to maximize consistency, vertical metric stability, and loading performance.

- **Tabular Numerics Rule:** Any table cell, financial ledger, metric widget, stock ticker, or timestamp must enforce `font-feature-settings: "tnum" 1, "cv05" 1, "cv08" 1`. This aligns numeric values into identical vertical column paths without ragged variance across ledger lines.
- **Micro-Copy Constraints:** Compact UI indicators (such as input labels and table headers) apply uppercase transformations with `letter-spacing: 0.05em` at 11px to retain legibility amid dense form layouts.
- **Hierarchy Enforcements:** Headline levels are strictly functional: `headline-xl` is reserved for major dashboard anchors, `headline-lg` designates module roots, and `headline-sm` denotes panel/table titles.

## Layout & Spacing

The layout philosophy follows a high-density, fluid-first grid engineered for screens from 1280px to 4K displays, with deterministic degradation for compact viewpoints:

- **Desktop (1280px+):** Collapsible 240px primary shell rail; fluid multi-column workspace driven by 12-column layout with 1.5rem gutters. Horizontal padding in data grids tightens to 0.75rem to increase visible columns above the fold.
- **Tablet (768px - 1279px):** Primary rail collapses to a 56px icon dock; main workspace enforces horizontal scroll zones on tables larger than 6 columns while pinning primary identifier and status columns.
- **Mobile (<768px):** Navigation transitions to bottom navigation bar or drill-down drawer. Complex data grids reflow into structured key-value card stacks.
- **Density Index:** The standard horizontal and vertical rhythm operates on 4px and 8px coordinate intervals. Forms rely on a uniform 32px height standard for inputs and inline actions in standard density, with a 28px variant for compact transactional order grids.

## Elevation & Depth

Visual separation relies on sharp structural outlines and disciplined surface-container tones, minimizing heavy ambient shadows:

- **Surface Tiers:**
  - Base: `#F8FAFC` (Canvas application shell)
  - Surface 0: `#FFFFFF` (Data tables, forms, content panels)
  - Surface 1: `#F1F5F9` (Nested headers, table head bands, frozen cell anchors)
  - Surface 2: `#FFFFFF` (Floating context flyouts, dropdown menus, quick-entry sheets)

- **Outlines over Elevation:**
  Containers, cards, and modal dialogs use a crisp 1px solid border (`#E2E8F0`). 

- **Shadow Rules:**
  - Resting panels: No shadow (`box-shadow: none`). Separation is achieved purely via borders.
  - Active dropdowns, auto-completes, and popovers: `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
  - Transactional Modals & Slide-out Drawers: `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.08)`.

## Shapes

The design system implements a strict "Soft" structural geometry (`roundedness: 1`). Enterprise ERP density fails when soft curves bleed into data boundaries; therefore:

- Standard inputs, buttons, status chips, and table cell highlights adopt `0.25rem` (4px) corner radii.
- Card panels, data containers, and slide-in trays apply `0.375rem` (6px) corner radii.
- Modal shells apply `0.5rem` (8px).
- Full circular radii (`9999px`) are banned except for user avatars and circular system status dot indicators.

## Components

- **Data Grids & Financial Tables:**
  - Headers: Height 32px, text `#64748B`, font size 11px, bold, uppercase tracking, background `#F8FAFC`, border-bottom 1px solid `#CBD5E1`.
  - Body Rows: Height 36px (dense) or 44px (default). Borders 1px solid `#F1F5F9`. Hover state shifts row surface to `#F8FAFC`.
  - Numeric alignment: Right-aligned with tabular numerals (`Inter`, `font-feature-settings: "tnum"`). Text left-aligned. Statuses centered.
  - Pinned Columns: Supported via border-right 1px solid `#CBD5E1` with solid background `#FFFFFF`.

- **Buttons:**
  - Primary: Background `#0F172A`, text `#FFFFFF`, radius 4px, height 32px, horizontal padding 12px. Hover: `#1E293B`. Focus: 2px ring `#2563EB` with 2px offset.
  - Secondary: Background `#FFFFFF`, text `#0F172A`, border 1px solid `#CBD5E1`. Hover: `#F8FAFC`.
  - Destructive: Background `#DC2626`, text `#FFFFFF`. Hover: `#B91C1C`.
  - Dense/Icon-only: 28px by 28px dimension, 4px radius, low-contrast slate icon.

- **Status Badges & Chips:**
  - Compact capsule construction: 20px fixed height, 4px radius, 6px horizontal padding.
  - Typography: 11px font size, weight 600.
  - State composition: Pair a 6px solid circular dot with the state text. Example: Draft has `#F59E0B` dot, `#D97706` text, `#FFFBEB` background, and `#FDE68A` border.

- **Form Fields & Inputs:**
  - Height 32px, font size 13px, border 1px solid `#CBD5E1`, border-radius 4px, horizontal padding 8px.
  - Focus state: Border color `#2563EB`, box-shadow `0 0 0 1px #2563EB`.
  - Error state: Border color `#DC2626`, background `#FEF2F2`.
  - Labels: Placed above fields, 11px uppercase bold, color `#475569`, bottom margin 4px.

- **Checkboxes & Radios:**
  - Checkboxes: 14px by 14px, 3px border radius, border 1px solid `#94A3B8`. Active fill `#2563EB` with `#FFFFFF` checkmark.
  - Radios: 14px diameter, 1px border. Selected state hosts 6px internal solid dot.

- **Breadcrumbs & Navigation Context:**
  - 20px bar height, text 12px, muted link `#64748B`, slash separator `#CBD5E1`. Active current node: `#0F172A` bold.

- **Keyboard Shortcut Indicators (KBD):**
  - Height 18px, min-width 18px, inline-flex, center-aligned, border 1px solid `#CBD5E1`, background `#F1F5F9`, color `#475569`, border-radius 3px, font size 10px, weight 600, tabular figures.